﻿using System;
using System.Collections.Generic;
using System.Data.Odbc;
using System.Windows;

namespace OBTtest_MS
{
	public class dbFieldNumber
	{
		static private int fn = 17; // Число полей всего
		static public int N
		{
			get => fn;
			/*
			set
			{
				fn = value;
			}
			*/
		}

		static private int vn = fn - 4; // Число полей для чисел
		static public int VN
		{
			get => vn;
		}

	}

	public class recList : List<string[]> { }
	public class myDBManager
	{
        // Информация для подключения.
        // Однако работаем через подготовленный источник данных, все настройки в нём.
        /*
		const string Host = "localhost";
		const string User = "postgres";
		const string DBname = "postgres";
		const string Password = "1";
		const string Port = "5432";

		private static string connString;

		private string connStringMaker() {
			return (connString =
					String.Format(
						"Server={0};Username={1};Database={2};Port={3};Password={4};SSLMode=Prefer",
						Host,
						User,
						DBname,
						Port,
						Password);
		}
		*/

        // Работаем через источник данных
        private const string sDSN = "DSN=PostgreSQL35W";


        // Строка с оператором создания таблицы.
        // Можно было бы сделать для [X2 .. X12] тип money, но поставим numeric,
		// чтобы явно объявить размер и не возиться с настройкой локали.
        private const string sCreateTable = "CREATE TABLE IF NOT EXISTS OBTtest (" +
			"X1A varchar(17), X1B varchar(1), X1V varchar(5), X1G varchar(3)," +
			"X2 numeric(12,2), X3 numeric(12,2), X4 numeric(12,2), X5 numeric(12,2), X6 numeric(12,2)," +
			"X7 numeric(12,2), X8 numeric(12,2), X9 numeric(12,2), X10 numeric(12,2), X11 numeric(12,2), X12 numeric(12,2)," +
			"X13 numeric(12,2),X14 numeric(12,2), CONSTRAINT main_idx PRIMARY KEY(X1A,X1B,X1V,X1G));";

		public myDBManager()
		{
			/*
			 * Здесь мог бы быть вызов connStringMaker();
			*/
		}

		public bool odbcOneCommand(string command, string errmes, bool IsFatal)
		{

			OdbcConnection odbc = new OdbcConnection();
			odbc.ConnectionString = sDSN;
			try
			{
				odbc.Open();
			}
			catch (Exception)
			{
				if (IsFatal == true)
				{
					MessageBox.Show("Ошибка соединения с сервером! Аварийный выход из программы.", "ОШИБКА РАБОТЫ С БАЗОЙ",
									 MessageBoxButton.OK,
									 MessageBoxImage.Exclamation);
					Environment.Exit(0);
				}
				else
                {
					MessageBox.Show("Ошибка соединения с сервером! Попробуйте позднее.", "ОШИБКА РАБОТЫ С БАЗОЙ",
						MessageBoxButton.OK, MessageBoxImage.Exclamation);
				}
				return false;
			}
			/*
			MessageBox.Show("Отладочное сообщение: всё идёт по плану.", "Управляющий базой данных",  
                                 MessageBoxButton.OK,  
                                 MessageBoxImage.Information);
			*/


			OdbcCommand odbcCommand = odbc.CreateCommand();
			odbcCommand.CommandText = command;
			try
			{
				odbcCommand.ExecuteNonQuery();
			}
			catch (Exception e)
			{
				MessageBox.Show(errmes + " [" + e.Message + "]",
					"ОШИБКА РАБОТЫ С БАЗОЙ", MessageBoxButton.OK, MessageBoxImage.Exclamation);
				MessageBox.Show("Команда: " + command + "]",
					"ОШИБКА РАБОТЫ С БАЗОЙ", MessageBoxButton.OK, MessageBoxImage.Exclamation);
				return false;
			}

			odbcCommand.Dispose();
			odbc.Close();
			return true;
		}

		public void CheckIfDBExists()
        {
			odbcOneCommand(sCreateTable, "Ошибка создания таблицы", true);
		}

		public void DeleteAll()
		{
			odbcOneCommand("DELETE FROM OBTtest", "Ошибка удаления всех записей", true);
		}

		public void DeleteOneRecord(string[] prm)
        {
			string sCommandTextFormat = "DELETE FROM OBTtest WHERE X1A = '{0}' AND X1B = '{1}' AND X1V = '{2}' AND X1G = '{3}'";
			string sCommandText = String.Format(sCommandTextFormat, prm);
			
			odbcOneCommand(sCommandText, "Ошибка удаления одной строки из базы данных", true);
		}

		public bool AddOrCreateOneString(string[] prm)
		{
			string sCommandTextFormat =
				"DO $$\nDECLARE cnt integer;\n" +
				"BEGIN\n" +
				"SELECT count(*) INTO cnt FROM OBTtest WHERE X1A = '{0}' AND X1B = '{1}' AND X1V = '{2}' AND X1G = '{3}';\n" +
				"IF cnt > 0 THEN\n" +
				"UPDATE OBTtest SET X2={4},X3={5},X4={6},X5={7},X6={8},X7={9},X8={10},X9={11},X10={12},X11={13},X12={14},X13={15},X14={16}" +
				" WHERE  X1A = '{0}' AND X1B = '{1}' AND X1V = '{2}' AND X1G = '{3}';\n" +
				"ELSE\n" +
				"INSERT INTO OBTtest VALUES('{0}','{1}','{2}','{3}',{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},{15},{16});\n" +
				"END IF;\n" +
				"END; $$ LANGUAGE plpgsql;";

			string sCommandText = String.Format(sCommandTextFormat, prm);

			return odbcOneCommand(sCommandText, "Ошибка добавления/обновления строки базы данных", false);
		}

		public recList odbcReadFromDB(string filter, bool IsFatal)
		{

			OdbcConnection odbc = new OdbcConnection();
			odbc.ConnectionString = sDSN;
			try
			{
				odbc.Open();
			}
			catch (Exception)
			{
				if (IsFatal == true)
				{
					MessageBox.Show("Ошибка соединения с сервером! Аварийный выход из программы.", "ОШИБКА РАБОТЫ С БАЗОЙ",
									 MessageBoxButton.OK,
									 MessageBoxImage.Exclamation);
					Environment.Exit(0);
				}
				else
				{
					MessageBox.Show("Ошибка соединения с сервером! Попробуйте позднее.", "ОШИБКА РАБОТЫ С БАЗОЙ",
						MessageBoxButton.OK, MessageBoxImage.Exclamation);
				}
				return null;
			}


			OdbcCommand odbcCommand = odbc.CreateCommand();
			odbcCommand.CommandText = "SELECT * FROM OBTtest " + filter + " ORDER BY X1A,X1B,X1V,X1G ;";

			recList rl = new();

			try
			{
				OdbcDataReader dbReader = odbcCommand.ExecuteReader();
				int fCount = dbReader.FieldCount; // Число полей в каждой записи

				if (dbReader.HasRows)
				{
					while (dbReader.Read())
					{
						object[] ss = new object[fCount];
						string[] ss2 = new string[fCount];
						int irez = dbReader.GetValues(ss);

						for(int i = 0;i < irez;i++)
                        {
							ss2[i] = ss[i].ToString();
						}

						rl.Add(ss2);
					}
				}

				dbReader.Close();
			}
			catch (Exception e)
			{
				MessageBox.Show(" Неудачное чтение базы: [" + e.Message + "]",
					"ОШИБКА РАБОТЫ С БАЗОЙ", MessageBoxButton.OK, MessageBoxImage.Exclamation);
				return null;
			}

			odbcCommand.Dispose();
			odbc.Close();
			return rl;
		}
	}
}