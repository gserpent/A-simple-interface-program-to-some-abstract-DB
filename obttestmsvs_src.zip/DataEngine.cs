﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;
using System.Windows;
using System.Text.RegularExpressions;
using System.Globalization;

namespace OBTtest_MS
{
    public class ShowList : INotifyPropertyChanged
	{
		private string[] x;
		public string[] ListX
		{
			get => x;
			set
			{
				x = value;
				// Уведомляем об изменении свойства
				NotifyPropertyChanged();
			}
		}

		#region Реализация INPC — обычно выносится в отдельный базовый класс
		private void NotifyPropertyChanged([CallerMemberName] string propertyName = null)
		{
			PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
		}

		public event PropertyChangedEventHandler PropertyChanged;
		#endregion
	}


	class DataStruct
	{
		string[] X;

		public DataStruct(string[] ss)
		{
			X = (string[])ss.Clone();
		}

		public bool IsThis(string[] ss)
		{
			return (ss[0] == X[0]) &&
				(ss[1] == X[1]) &&
				(ss[2] == X[2]) &&
				(ss[3] == X[3]);
		}

		private static bool MakeOneMatch(string s, string t)
		{
			RegexOptions options = RegexOptions.IgnoreCase | RegexOptions.IgnorePatternWhitespace;
			try
			{
				if ((t != null) && (t.Length != 0))
				{
					if (!Regex.Match(s, t, options).Success)
					{
						return false;
					}
				}
			}
			catch(Exception)
            {
				return false;
			}
			return true;
        }
		public bool IsThisMatch(string[] ss)
		{
			return MakeOneMatch(X[0], ss[0]) && MakeOneMatch(X[1], ss[1]) && MakeOneMatch(X[2], ss[2]) && MakeOneMatch(X[3], ss[3]);
		}

		public void ClearX()
		{
			Array.Clear(X, 0, X.Length);
		}

		public bool WriteToDB()
		{
			myDBManager myDBM = new();
			return myDBM.AddOrCreateOneString(X);
		}

		public void WriteToCollection(ObservableCollection<ShowList> prm)
		{
			prm.Add(new ShowList { ListX = (string[])X.Clone() });
		}
	}

    internal class DataList : List<DataStruct>
	{
		/*
		public bool NotInList(string[] prm)
		{

			foreach (DataStruct item in this)
			{
				if (item.IsThis(prm))
				{
					return false;
				}
			}
			return true;
		}

		public DataStruct FindByCode(string[] prm)
		{
			foreach (DataStruct item in this)
			{
				if (item.IsThis(prm))
				{
					return item;
				}
			}
			return null;
		}
		*/

		private int FindIndxByCode(string[] prm)
		{
			for (int i = 0;i < this.Count;i++)
			{
				if (this[i].IsThis(prm))
				{
					return i;
				}
			}
			return -1;
		}

		public void DelRecord(string[] selection)
        {
			int i = FindIndxByCode(selection);
			if (i != -1)
            {
				this[i].ClearX();
				this.RemoveAt(i);
			}
        }

		public void ClearData()
		{
			foreach (DataStruct item in this)
			{
				item.ClearX();
			}
			this.Clear();
		}

		public void WriteToDB()
		{
			int counter = 0;
			foreach (DataStruct item in this)
			{
				if (item.WriteToDB() == false)
				{
					string message = "Записано в базу строк " + counter.ToString() + " из " + Count.ToString()
						+ ". Продолжить работу программы?";
					var result = MessageBox.Show(message, "ОШИБКА РАБОТЫ С БАЗОЙ",
										 MessageBoxButton.OKCancel,
										 MessageBoxImage.Hand);
					if (result == MessageBoxResult.Cancel)
					{
						Environment.Exit(0);
					}
					return;
				}
			}
		}

		public void ReadFromDB(string filter = "", bool IsFatal = true)
		{
			this.ClearData();

			myDBManager myDBM = new myDBManager();

			recList rl = myDBM.odbcReadFromDB(filter, IsFatal);
			if (rl != null)
			{
				foreach (string[] item in rl)
				{
					this.Add(new DataStruct(item));
				}
			}
		}
		public void WriteToCollection(ObservableCollection<ShowList> prm)
		{
			prm.Clear();

			foreach (DataStruct item in this)
			{
				item.WriteToCollection(prm);
			}
		}
		public void WriteToCollectionWithFilter(ObservableCollection<ShowList> prm, string[] filter)
		{
			prm.Clear();

			foreach (DataStruct item in this)
			{
				if (item.IsThisMatch(filter))
				{
					item.WriteToCollection(prm);
				}
			}
		}



        public class DataEngine
		{
			
			static DataList mainBuffer = new();

			// Для сравнения двух строк в БД (= в главном буфере)
			public CompareClass comparator = new(mainBuffer);

			public class CompareClass
			{
				DataChell item1, item2;

				static DataList mainBuffer;

				// Конструктор этого класса
				public CompareClass(DataList mBuffer)
                {
					mainBuffer = mBuffer;
				}

				public string Report()
                {
					string s = "";
					if ((item1 == null) || (item2 == null))
                    {
						ErrorInfoMsg("Невозможно сформировать отчёт - проверьте Ваш выбор.");
						return null;
                    }
					if ((item1.CheckIfInBuffer() == false) || (item2.CheckIfInBuffer() == false))
					{
						ErrorInfoMsg("Ошибка списка - перечитайте из базы и сделайте Ваш выбор.");
						return null;
					}

					for(int i = 0; i < dbFieldNumber.VN; i++)
                    {
						string s1 = item1.VArr[i];
						string s2 = item2.VArr[i];
						if (s1.Length == 0) {
							s1 = "0.00";
						}
						if (s2.Length == 0) 
						{ 
							s2 = "0.00";
						}
						s += "Поле " + (i + 2).ToString() + ":\t\t" + s1 + "\t\t" + s2 + "\t\t(разность = " +
							(ToDouble(s1) - ToDouble(s2)).ToString("F2",provider) + ")\n";
					}
					return "Сравнение строки 1 с кодом " + item1.GetKey() + "\n и строки 2 с кодом " + item2.GetKey() + "\n\n" + s;
				}

				// Полезные вещи
				public void Clear()
                {
					item1 = null;
					item2 = null; ;
				}

				public string SetStr(string[] prm, int n)
				{
					if (mainBuffer.FindIndxByCode(prm) != -1)
					{
						switch (n)
						{
							//Установка первой строки
							case 1:
								if (item2 != null)
								{
									if (item2.IsIt(prm))
									{
										InfoMessage("Строка с кодом " + item2.GetKey() + " уже выбрана во втором поле.");
										if (item1 != null)
											return item1.GetKey();
										break;
									}
								}

								if (item1 == null)
								{
									item1 = new(prm);
								}
								else
								{
									item1.SetIt(prm);
								}
								return item1.GetKey();

							//Установка второй строки
							case 2:
								if (item1 != null)
								{
									if (item1.IsIt(prm))
									{
										InfoMessage("Строка с кодом " + item1.GetKey() + " уже выбрана в первом поле.");
										if(item2 != null)
											return item2.GetKey();
										break;
									}
								}

								if (item2 == null)
								{
									item2 = new(prm);
								}
								else
								{
									item2.SetIt(prm);
								}
								return item2.GetKey();

								// Иных случаев быть не может и не должно!
						}
					}
					else
					{
						switch (n)
						{
							case 1:
								item1 = null;
								break;
							case 2:
								item2 = null;
								break;
						}

						ErrorInfoMsg("Строка с кодом " + prm[0] + "" + prm[1] + "" + prm[2] + "" + prm[3] + " уже удалена!" +
							"Перечитайте данные из базы.");
					}

					// Возврат для всех нехороших случаев
					return MainWindow.NyetMsg;
				}

				// Класс для ячеек
				private class DataChell
				{
					private string k1, k2, k3, k4;
					private string[] vArray;
					public string[] VArr
					{
						get => vArray;
					}

					public DataChell(string[] prm)
					{
						vArray = new string[dbFieldNumber.VN];
						SetIt(prm);
					}
					public void SetIt(string[] prm) 
					{
						k1 = prm[0];
						k2 = prm[1];
						k3 = prm[2];
						k4 = prm[3];

						for (int i = 0, j = 4; j < dbFieldNumber.N; i++, j++)
						{
							vArray[i] = prm[j];
						}
					}

					public bool IsIt(string[] prm)
                    {
						return (k1 == prm[0]) && (k2 == prm[1]) && (k3 == prm[2]) && (k4 == prm[3]);
					}
					public string GetKey()
                    {
						return k1 + " " + k2 + " " + k3 + " " + k4;
					}

					public bool CheckIfInBuffer()
                    {
						string[] key = { k1, k2, k3, k4 };
						return (mainBuffer.FindIndxByCode(key) != -1);
					}
				}


				private readonly NumberFormatInfo provider = new NumberFormatInfo() { NumberDecimalSeparator = ".", NumberGroupSeparator = "" };

				private double ToDouble(string s)
				{
					return Convert.ToDouble(s.Replace(',', '.'), provider);
				}
			}



			// Функции для выдачи сообщений
			
			private static void InfoMessage(string message)
			{
				MessageBox.Show(message, MainWindow.MAINCAPTION, MessageBoxButton.OK, MessageBoxImage.Information);
			}

			private static void ErrorInfoMsg(string message)
			{
				MessageBox.Show(message, MainWindow.MAINCAPTION, MessageBoxButton.OK, MessageBoxImage.Hand);
			}

			private void CheckConnection()
			{
				myDBManager myDBM = new myDBManager();
				myDBM.CheckIfDBExists();
			}

			public DataEngine(ObservableCollection<ShowList> prmshowList)
			{
				CheckConnection();

				mainBuffer.ReadFromDB();
				mainBuffer.WriteToCollection(prmshowList);
			}

			public void ClearTable()
			{
				myDBManager myDBM = new myDBManager();
				myDBM.DeleteAll();
			}

			public void DeleteRecord(string[] selection)
			{
				myDBManager myDBM = new();
				myDBM.DeleteOneRecord(selection);
				mainBuffer.DelRecord(selection);
			}

			public void UpdateRecordInDB(string[] data)
			{
				myDBManager myDBM = new();
				myDBM.AddOrCreateOneString(data);
			}

			public int LoadFromFile(ObservableCollection<ShowList> prmshowList)
			{
				OpenFileDialog openFileDialog = new OpenFileDialog();

				openFileDialog.Filter = "Текстовые (*.txt)|*.txt|Все файлы (*.*)|*.*";
				openFileDialog.FilterIndex = 2;
				openFileDialog.RestoreDirectory = false;

				if (openFileDialog.ShowDialog() == false)
					return 0;

				string fileName = openFileDialog.FileName;

				string line;
				int linecounter = 0;

				DataList buffer = new DataList();

				Encoding cp1251;

				Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

				try
				{
					cp1251 = Encoding.GetEncoding("windows-1251");
				}
				catch
				{
					ErrorInfoMsg("Невозможно загрузить кодировку windows-1251, будет использована кодировка по умолчанию.");
					cp1251 = Encoding.Default;
				}

				try
				{
					using (StreamReader sr = new StreamReader(fileName, cp1251))
					{
						while ((line = sr.ReadLine()) != null)
						{
							linecounter++;

							if ((line[0] == '#') || (line[0] == '*') || (line.Substring(0, 5) == "ТБ = 01"))
								continue;

							string[] split = line.Replace(',', '.').Split('|');

							if (split.Length < dbFieldNumber.N)
							{
								//	this.ErrorInfoMsg("Строка " + linecounter.ToString() + " файла: [" + fn + "] - коротка: всего полей " + split.Length.ToString() + ".");
								continue;
							}
							buffer.Add(new DataStruct(split));
						}
					}
				}
				catch (IOException e)
				{
					ErrorInfoMsg("Ошибка чтения файла: " + e.Message);
					return -1;
				}

				buffer.WriteToDB();

				mainBuffer.ReadFromDB();
				mainBuffer.WriteToCollection(prmshowList);

				return buffer.Count;
			}

			public void ReReadAllFromDB(ObservableCollection<ShowList> prmshowList)
			{
				mainBuffer.ReadFromDB();
				mainBuffer.WriteToCollection(prmshowList);
			}

			public void DropFilter(ObservableCollection<ShowList> prmshowList)
			{
				mainBuffer.WriteToCollection(prmshowList);
			}

			public void SetFilter(ObservableCollection<ShowList> prmshowList, string[] filter)
			{
				mainBuffer.WriteToCollectionWithFilter(prmshowList, filter);
			}
		}
	}
}
