﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static OBTtest_MS.DataList;

namespace OBTtest_MS
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>

    public partial class MainWindow : Window
    {

        // Самое главное в Главном Окне - это заголовок с датой версии!!!
        // (Порой очень помогает при удалённом разговоре с пользователем)

        public const string MAINCAPTION = "OBTtest (09.12.2021)";

        // ***
        // Настройка поведения главного окна при появлении (и закрытии) дочернего окна
        // ***

        public enum winModes {oneWindow, // только одно окно на экране
            twoWindows,            // оба окна на экране, и оба доступны
            bgWindow              // оба окна на экране, но доступно только дочернее
        };


        // *** Раскоментировать одно из трёх - согласно желаемому режиму по умолчанию ***

         private const winModes defaultMode = (winModes.oneWindow);
        // private const winModes defaultMode = (winModes.twoWindows);
        //private const winModes defaultMode = (winModes.bgWindow);

        public class mainWindowModeClass
        {
            // Хранилище для текущего режима окна
            private winModes _mainWindowMode;

            // Настраивать при необходимости можно будет так
            public void setMainWindowMode(winModes prmMode) => _mainWindowMode = prmMode;

            public winModes getMainWindowMode(winModes prmMode) { return _mainWindowMode; }

            // ... или так (ненужный вариант - закомментировать)
            public winModes mainWindowMode
            {
                get => _mainWindowMode;
                set
                {
                    _mainWindowMode = value;
                }
            }

            // Также понадобится хранилище для указателя на главное окно (чтобы каждый раз за ним не бегать...)
            private MainWindow _mainWindow;

            // Конструктор устанавливает режим по умолчанию (для случая, когда нет сохранённой настройки)
            public mainWindowModeClass(MainWindow prmWin)
            {
                _mainWindowMode = defaultMode;
                _mainWindow = prmWin;
            }

            // ... или по желанию (если сохранённая настройка есть)
            public mainWindowModeClass(winModes prmMode, MainWindow prmWin)
            {
                _mainWindowMode = prmMode;
                _mainWindow = prmWin;
            }

            // Спрятать/деактивировать главное окно
            public void ToChild()
            {
                if (_mainWindowMode == winModes.bgWindow)
                {
                    _mainWindow.IsEnabled = false;
                }
                else
                {
                    if (_mainWindowMode == winModes.oneWindow)
                    {
                        _mainWindow.Visibility = Visibility.Hidden;
                    }

                }

            }

            // Показать и активировать главное окно
            public void FromChild()
            {
                _mainWindow.DropInfo();
                _mainWindow.IsEnabled = true;
                _mainWindow.Show();
                _mainWindow.Activate();
            }

        }

        // Объявляем экземпляр класса
        public mainWindowModeClass mWindowMode;


        // ***
        // Для работы с данными нужны будут эти классы
        // ***

        // Объявляем экземпляр класса, через который будем работать с БД
        private static DataEngine de;

        // ... и экземпляр коллекции для списочного поля на экране
        private readonly ObservableCollection<ShowList> showList = new();

        public static string curDir;


        // ***
        // Конструктор главного окна
        // ***
        public MainWindow()
        {
            InitializeComponent();

            // Сохраняем путь к директории, откуда стартовали...
            curDir = Directory.GetCurrentDirectory(); ;

            // ...и делаем другие нужные дела
            SetInfo("Загрузка базы...");
            mWindowMode = new mainWindowModeClass(this);
            de = new DataEngine(showList);
            lstw.ItemsSource = showList;

            if(showList.Count != 0)
            {
                lstw.SelectedIndex = 0;
            }

            DropInfo();
        }

        // Процедуры для работы с информационной строкой
        public void SetInfo(string s)
        {
            infoField.Content = s;
            infoField.Visibility = Visibility.Visible;
        }

        public void DropInfo()
        {
            infoField.Visibility = Visibility.Collapsed;
        }


        // ***
        // Далее идут обработчики кнопок
        // ***

        // Три "святые" кнопки редактирования
        private void AddRecordBtn_Click(object sender, RoutedEventArgs e)
        {
            SetInfo("Добавление записи...");
            EditWindow eWindow = new EditWindow();
            eWindow.Owner = this;//Делаем MainWindow родителем

            mWindowMode.ToChild();
            eWindow.Show(); 
        }

        private void EditRecordBtn_Click(object sender, RoutedEventArgs e)
        {
            EditWindow eWindow;
            int indx = lstw.SelectedIndex;
            if (showList.Count != 0)
            {
                if(lstw.SelectedIndex == -1)
                {
                    MessageBox.Show("Не выбрана запись для редактирования.",
                    MAINCAPTION, MessageBoxButton.OK, MessageBoxImage.Question);
                    return;
                }
                SetInfo("Редактирование записи...");

                string[] sSelection = new string[dbFieldNumber.N];
                
                sSelection = showList[indx].ListX;

                eWindow = new EditWindow(sSelection);
                eWindow.Title = sSelection[0] + " " + sSelection[1] + " " + sSelection[2] + " " + sSelection[3];
            }
            else
            { // Эта ветка в принципе не должна работать - просто нужно заблаговременно сделать кнопку редактирования неактивной
                SetInfo("Добавление записи...");
                eWindow = new EditWindow();
                eWindow.Owner = this;//Делаем MainWindow родителем

                mWindowMode.ToChild();
                eWindow.Show();

            }
            eWindow.Owner = this;             //Делаем MainWindow родителем

            mWindowMode.ToChild();
            eWindow.Show();
        }

        private void DelRecordBtn_Click(object sender, RoutedEventArgs e)
        {
            int indx = lstw.SelectedIndex;
            if (showList.Count != 0)
            {
                if (indx == -1)
                {
                    MessageBox.Show("Не выбрана запись для удаления.",
                    MAINCAPTION, MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                string[] sSelection = new string[dbFieldNumber.N];
                sSelection = showList[indx].ListX;
                var result = MessageBox.Show("Вы действительно хотите удалить запись с ключом " +
                    sSelection[0] + " " + sSelection[1] + " " + sSelection[2] + " " + sSelection[3] +
                    " из базы данных?",
                    MAINCAPTION, MessageBoxButton.OKCancel, MessageBoxImage.Question);
                if (result == MessageBoxResult.OK)
                {
                    string[] selection = new string[] { sSelection[0], sSelection[1], sSelection[2], sSelection[3] };
                    de.DeleteRecord(selection);
                    showList.RemoveAt(indx);
                }
            }
            else
            {// Эта ветка в принципе не должна работать - просто нужно заблаговременно сделать кнопку удаления неактивной
                MessageBox.Show("Нет записей для удаления.",MAINCAPTION, MessageBoxButton.OK, MessageBoxImage.Question);
                return;
            }
        }


        // ... ещё кнопка для полной очистки данной таблицы в БЛ. В боевой программе следует закомментировать эту кнопку
        // или хотя бы закрыть достуа жёстким администраторским паролем. 

        private void ClearBtn_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Вы действительно хотите удалить ВСЕ записи из базы данных? ДЕЙСТВИТЕЛЬНО????!!!",
                MAINCAPTION, MessageBoxButton.OKCancel, MessageBoxImage.Question);
            if (result == MessageBoxResult.OK)
            {
                de.ClearTable();
                showList.Clear();
            }

        }


        // Кнопка выхода
        private void QuitBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }


        // Кнопка загрузки из файла и кнопки выгрузки в файлы

        private void LoadBtn_Click(object sender, RoutedEventArgs e)
        {
            int iCount = de.LoadFromFile(showList);
            if(iCount > 0)
            {
                MessageBox.Show("Загружено элементов: " + iCount.ToString() + ".", MAINCAPTION, MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void ToXMLBtn_Click(object sender, RoutedEventArgs e)
        {
            SetInfo("Выгрузка в файл XML");
            // SaveToXml.Run(showList);
            _ = SaveToXmlByXml.Run(showList);

            _ = MessageBox.Show("Выгрузка в файл XML завершена.",
                MAINCAPTION, MessageBoxButton.OK, MessageBoxImage.Information);
            SetInfo("");
        }

        private void ToExcelBtn_Click(object sender, RoutedEventArgs e)
        {
            SetInfo("Выгрузка в файл Excel");
            try
            {
                int n = 0;

                //if(SaveToExcel.Run(this, showList) > 0)  // вызов старой глючной процедуры - оставлено на память...

                if ((n = SaveToExcelSyncfusion.Run(this, showList)) >= 0)
                {
                    MessageBox.Show("Выгрузка в формате Excel завершена. Выгружено строк " + n,
                        MAINCAPTION, MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception er)
            {
                MessageBox.Show("Выгрузка в формате Excel закончилась неудачно: [" + er.Message + "]",
                    MAINCAPTION, MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
            SetInfo("");
        }


        // Кнопки установки и отмены отбора в списке

        private void SetFilterBtn_Click(object sender, RoutedEventArgs e)
        {
            if((X1Afilter.Text.Length == 0) && (X1Bfilter.Text.Length == 0) && (X1Vfilter.Text.Length == 0) 
                && (X1Gfilter.Text.Length == 0))
            {
                de.DropFilter(showList);
            }
            else
            {
                string[] filter = new string[] { X1Afilter.Text, X1Bfilter.Text, X1Vfilter.Text, X1Gfilter.Text };
                de.SetFilter(showList, filter);
            }
        }

        private void DropFilterBtn_Click(object sender, RoutedEventArgs e)
        {
            X1Afilter.Text = X1Bfilter.Text = X1Vfilter.Text = X1Afilter.Text = "";
            de.DropFilter(showList);
        }


        // ***
        // Сравнение строк БД (на самом деле - из главного буфера)
        // ***

        public const string NyetMsg = "<<НЕТ>>";
        // Выбор первой строки
        private void TakeStr1Btn_Click(object sender, RoutedEventArgs e)
        {
            Str1Field.Content = SetStr(1);
        }

        // Выбор второй строки
        private void TakeStr2Btn_Click(object sender, RoutedEventArgs e)
        {
            Str2Field.Content = SetStr(2);
        }

        // ... и процедура сравнения
        private void CompareBtn_Click(object sender, RoutedEventArgs e)
        {
            SetInfo("Формирую отчёт...");

            string rez = de.comparator.Report();
            if (rez != null)
            {
                CompareWindow compareWindow = new CompareWindow(rez);
                compareWindow.Owner = this;//Делаем MainWindow родителем
                mWindowMode.ToChild();
                compareWindow.Show();
                SetInfo("");
            }
        }

        private string SetStr(int n)
        {
            int indx = lstw.SelectedIndex;
            if (showList.Count == 0)
            {
                return NyetMsg;
            }
            if (indx == -1)
            {
                MessageBox.Show("Не выбрана запись для зансения в поле.",
                MAINCAPTION, MessageBoxButton.OK, MessageBoxImage.Information);
                return NyetMsg;
            }

            return de.comparator.SetStr(showList[indx].ListX, n);
        }

        // ***
        // А также понадобятся эти процедуры для работы с данными
        // ***
        public void UpdateRecordInDB(string[] prm)
        {
            SetInfo("Обновляю запись в базе");
            string[] data = prm;
            de.UpdateRecordInDB(data);
            SetInfo("");
        }
        
        public void ReReadAll()
        {
            SetInfo("Читаю из базы, ждите...");
            de.ReReadAllFromDB(showList);
            SetInfo("");
        }

        private void ReReadBtn_Click(object sender, RoutedEventArgs e)
        {
            ReReadAll();
        }

    }
}
