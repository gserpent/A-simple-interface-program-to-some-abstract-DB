﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using Microsoft.Win32;
using System.Globalization;
using System.Xml;

/*
using System.Data;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml.Packaging;
using System.Linq;
*/
using Syncfusion.XlsIO;


namespace OBTtest_MS
{


    public class SaveToXmlByXml
    {

        static NumberFormatInfo provider; // Описатель формата для преобразования строки в вещественное число 

        private class DataStructClass
        {
            private string _sintSchet;
            public string SintSchet
            {
                get => _sintSchet;
                set
                {
                    _sintSchet = value;
                }
            }

            private string _kosgu;
            public string Kosgu
            {
                get => _kosgu;
                set
                {
                    _kosgu = value;
                }
            }

            private double[] _x = new double[dbFieldNumber.VN];
            public double[] X
            {
                get => _x;
                set
                {
                    _x = value;
                }
            }

            public DataStructClass(string[] ss)
            {
                _sintSchet = ss[2];
                _kosgu = ss[3];
                for (int i = 0, j = 4; j < dbFieldNumber.N; i++, j++)
                {
                    _x[i] = Convert.ToDouble(ss[j].Replace(',', '.'), provider);
                }
            }

            public DataStructClass()
            {
                _sintSchet = "88888";
                _kosgu = "888";
                for (int i = 0, j = 4; j < dbFieldNumber.N; i++, j++)
                {
                    _x[i] = 0;
                }
            }

            public bool IsThis(string[] ss)
            {
                return (_sintSchet == ss[2]) && (_kosgu == ss[3]);
            }

            public void Update(string[] ss)
            {
                for (int i = 0, j = 4; j < dbFieldNumber.N; i++, j++)
                {
                    try
                    {
                        if ((ss[j] != null) && (ss[j].Trim().Length != 0))
                        {
                            _x[i] += Convert.ToDouble(ss[j].Replace(',', '.'), provider);
                        }
                    }
                    catch (Exception e)
                    {
                        ErrorInfoMsg("Попытка конвертации в число: " + e.Message + ", параметр [" + ss[j] + "]");
                        Environment.Exit(0);
                    }

                }
            }

            public bool Output(XmlWriter writer)
            {
                string[] s1 = new string[dbFieldNumber.VN];
                string[] s2 = new string[dbFieldNumber.VN];
                int n = 0;
                for (int i = 0, k = 2; i < dbFieldNumber.VN; i++, k++)
                {
                    if (_x[i] != 0)
                    {
                        s1[n] = "_x" + k.ToString();
                        s2[n] = _x[i].ToString("F2");
                        n++;
                    }

                }
                if (n > 0)
                {

                    writer.WriteStartElement(itemname); // private const string itemname = "Data";
                    writer.WriteAttributeString(prm1name, _sintSchet);//writer.WriteAttributeString(prm1name, s1); // private const string prm1name = "СинтСчёт";
                    writer.WriteAttributeString(prm2name, _kosgu); // private const string prm2name = "КОСГУ";
                    for (int i = 0; i < n; i++)
                    {
                        try
                        {
                            writer.WriteAttributeString(s1[i], s2[i]);
                        }
                        catch(Exception e)
                        {
                            ErrorInfoMsg("Ошибка записи реквизита " + i + " c именем " + s1[i] + " и значением " + s2[i] +
                                ", сообщение: " + e.Message);
                        }
                        
                    }
                    writer.WriteEndElement();
                    return true;
                }
                return false;
            }
        }

        private class DataListClass : List<DataStructClass>
        {
            private DataStructClass sumData = new();

            public bool SumDataOutput(XmlWriter writer)
            {
                return sumData.Output(writer);
            }

            public void AddData(string[] prm)
            {
                sumData.Update(prm);

                foreach (DataStructClass item in this)
                {
                    if (item.IsThis(prm))
                    {

                        item.Update(prm);
                        return;
                    }
                }
                Add(new DataStructClass(prm));
            }
        }

        // Класс для возврата значения

            private static void ErrorInfoMsg(string message)
        {
            MessageBox.Show(message, MainWindow.MAINCAPTION, MessageBoxButton.OK, MessageBoxImage.Hand);
        }

        /*
        private const string header =
"<? xml version = \"1.0\" encoding=\"windows-1251\"?>\n";
*/
        private const string name1 = "RootXml";
        private const string name2 = "Report";
        private static string[] string2 = { "Code", "042", "AlbumCode", "МЕС_К" };
        private const string name3 = "FormVariant";
        private static string[] string3 = { "Number", "1", "NsiVariantCode", "0000" };
        private const string name4 = "Table";
        private static string[] string4 = { "Code", "Строка", };

        private const string itemname = "Data";
        private const string prm1name = "СинтСчёт";
        private const string prm2name = "КОСГУ";


        public static int Run(ObservableCollection<ShowList> prmshowList)
        {
            // Сначала спросим, правда ли пользователь хочет выгрузить данные?
            // Или случайно нажал не ту кнопку...
            SaveFileDialog saveFileDialog = new();

            saveFileDialog.Filter = "Файлы XML (*.xml)|*.xml|All files (*.*)|*.*";
            saveFileDialog.FilterIndex = 1;
            saveFileDialog.RestoreDirectory = true;

            if (saveFileDialog.ShowDialog() == false)
                return 0;


            // Теперь - подсчёт.
            provider = new NumberFormatInfo() { NumberDecimalSeparator = ".", NumberGroupSeparator = "" };

            DataListClass buffer = new DataListClass();

            foreach (ShowList show in prmshowList)
            {
                buffer.AddData(show.ListX);
            }


            // Теперь - отчёт.
            string fileName = saveFileDialog.FileName;


            Encoding cp1251;

            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

            try
            {
                cp1251 = Encoding.GetEncoding("windows-1251");
            }
            catch
            {
                ErrorInfoMsg("Невозможно загрузить кодировку windows-1251, будет использована кодировка по умолчанию.");
                cp1251 = Encoding.Default;
            }

            int linecount = 0;

            try
            {

                //using (StreamWriter sw = new StreamWriter(fileName, false, cp1251))

                XmlWriterSettings settings = new XmlWriterSettings();
                settings.Indent = true;
                settings.NewLineOnAttributes = false;
                settings.Encoding = cp1251;

                using (XmlWriter writer = XmlWriter.Create(fileName, settings))
                {

                    writer.WriteStartElement(name1); // private const string name1 = "RootXml";

                    writer.WriteStartElement(name2); // private const string name2 = "Report";
                    writer.WriteAttributeString(string2[0], string2[1]); // private string[] string2 = { "Code", "042",
                    writer.WriteAttributeString(string2[2], string2[3]); // "AlbumCode", "МЕС_К" };

                    writer.WriteStartElement(name3); // private const string name3 = "FormVariant";
                    writer.WriteAttributeString(string3[0], string3[1]); // private string[] string3 = { "Number", "1", 
                    writer.WriteAttributeString(string3[2], string3[3]); // "NsiVariantCode", "0000" };

                    writer.WriteStartElement(name4); // private const string name4 = "Table";
                    writer.WriteAttributeString(string4[0], string4[1]); // private string[] string4 = { "Code", "Строка", };

                    

                    foreach (DataStructClass item in buffer)
                    {
                        if (item.Output(writer))
                        {
                            linecount++;
                        }
                    }
                    
                    if (linecount > 0)
                    {
                        _ = buffer.SumDataOutput(writer);
                        linecount++;
                    }

                    writer.WriteEndElement();
                    writer.WriteEndElement();
                    writer.WriteEndElement();
                    writer.WriteEndElement();
                }
            }
            catch (IOException e)
            {
                ErrorInfoMsg("Ошибка чтения файла: " + e.Message);
                return -1;
            }
            return linecount;
        }

    }


    public class SaveToExcelSyncfusion
    {

        public static int Run(MainWindow main, ObservableCollection<ShowList> prmshowList)
        {
            // Сначала проверим, существует ли шаблон
            string templateName = "template.xlsx";
            string templateFullPath = MainWindow.curDir + "\\" + templateName;



            if (!File.Exists(templateFullPath))
            {
                ErrorInfoMsg("Отсутствует файл шаблона с именем " + templateFullPath + ", формирование документа прекращено.");
                return -1;
            }

            // Спросим, правда ли пользователь хочет выгрузить данные?
            // Или случайно нажал не ту кнопку...
            SaveFileDialog saveFileDialog = new()
            {
                Filter = "Файлы XLSX (*.xlsx)|*.xlsx|All files (*.*)|*.*",
                FilterIndex = 1,
                RestoreDirectory = true
            };

            if (saveFileDialog.ShowDialog() == false)
            {
                return -2;
            }

            string targetFileFullPath = saveFileDialog.FileName;
            try
            {
                File.Copy(templateFullPath, targetFileFullPath, true);
            }
            catch (Exception e)
            {
                ErrorInfoMsg("Ошибка создания файла: " + e.Message);
                return -1;
            }

            // И вперёд.

            NumberFormatInfo provider = new NumberFormatInfo() { NumberDecimalSeparator = ".", NumberGroupSeparator = "" };

            double[] summary = new double[dbFieldNumber.VN];

            int counter = 0;
            string emptyCellMark = "-"; // однократное тире

            using (ExcelEngine excelEngine = new ExcelEngine())
            {
                FileStream SourceStream = File.Open(targetFileFullPath, FileMode.Open);

                //Loads or open an existing workbook through Open method of IWorkbooks
                IWorkbook workbook = excelEngine.Excel.Workbooks.Open(SourceStream);
                SourceStream.Close();

                IApplication application = excelEngine.Excel;

                //Optimize parsing
                application.UseFastRecordParsing = true;

                //Accessing via index
                IWorksheet worksheet = workbook.Worksheets[0];

                try
                {
                    string[] buf; // /// = new string[dbFieldNumber.N];
                    int rowIndex = 6;

                    foreach (ShowList show in prmshowList)
                    {
                        buf = show.ListX;

                        worksheet.InsertRow(rowIndex, 1, ExcelInsertOptions.FormatAsBefore);

                        worksheet.Range[rowIndex, 1].Text = (buf[0] + " " + buf[1] + " " + buf[2] + " " + buf[3]);

                        for (int i = 0, j = 4, k = 2; j < dbFieldNumber.N; i++, j++, k++)
                        {
                            double dd = Convert.ToDouble(buf[j].Replace(',', '.'), provider);
                            Syncfusion.XlsIO.IRange range = worksheet.Range[rowIndex, k];

                            if (dd != 0)
                            {
                                summary[i] += dd;
                                range.NumberFormat = "0.00";
                                range.Number = dd;
                            }
                            else
                            {
                                range.Text = emptyCellMark;
                            }
                        }

                        rowIndex++;
                        counter++;

                        //
                        // Сообщение о прогрессе - но оно будет работать только в отдельной нити - и то если переделать её
                        // ***   main.SetInfo("Выгрузка в файл Excel: создано строк " + (++counter).ToString());
                        //
                    }

                    // Пишем итоги
                    worksheet.InsertRow(rowIndex, 1, ExcelInsertOptions.FormatAsBefore);

                    worksheet.Range[rowIndex, 1].Text = "Всего задолженности:";

                    for (int i = 0, k = 2; i < dbFieldNumber.VN; i++, k++)
                    {
                        Syncfusion.XlsIO.IRange range = worksheet.Range[rowIndex, k];
                        if (summary[i] != 0)
                        {
                            range.NumberFormat = "0.00";
                            range.Number = summary[i];
                        }
                        else
                        {
                            range.Text = emptyCellMark;
                        }

                    }
                }
                catch (Exception e)
                {
                    ErrorInfoMsg("Формирование документа прервано из за ошибки: " + e.Message);
                    return -1;
                }


                //Set the version of the workbook
                workbook.Version = ExcelVersion.Excel2013;

                //Save the workbook in file system as XLSX format
                SourceStream = File.Create(targetFileFullPath);
                workbook.SaveAs(SourceStream);
                SourceStream.Close();

            }
            return counter;
        }
        private static void ErrorInfoMsg(string message)
        {
            _ = MessageBox.Show(message, MainWindow.MAINCAPTION, MessageBoxButton.OK, MessageBoxImage.Hand);
        }

    }
}


//
//  *** Выгрузка в формате XML, написанная ручками
//
/*
public class SaveToXml
{
    private const string header =
        "<? xml version = \"1.0\" encoding=\"windows-1251\"?>\n" +
        "<RootXml>\n" +
        "  <Report Code = \"042\" AlbumCode=\"МЕС_К\">\n" +
        "    <FormVariant Number = \"1\" NsiVariantCode=\"0000\">\n" +
        "      <Table Code = \"Строка\">\n";
    private const string indent =
        "        ";
    private const string footer =
        "      </Table>\n" +
        "    </FormVariant>\n" +
        "  </Report>\n" +
        "</RootXml>";


    static NumberFormatInfo provider; // Описатель формата для преобразования строки в вещественное число 

    private class DataStructClass
    {
        private string _sintSchet;
        public string SintSchet
        {
            get => _sintSchet;
            set
            {
                _sintSchet = value;
            }
        }

        private string _kosgu;
        public string Kosgu
        {
            get => _kosgu;
            set
            {
                _kosgu = value;
            }
        }

        private double[] _x = new double[dbFieldNumber.VN];
        public double[] X
        {
            get => _x;
            set
            {
                _x = value;
            }
        }

        public DataStructClass(string[] ss)
        {
            _sintSchet = ss[2];
            _kosgu = ss[3];
            for (int i = 0, j = 4; j < dbFieldNumber.N; i++, j++)
            {
                _x[i] = Convert.ToDouble(ss[j].Replace(',', '.'), provider);
            }
        }

        public DataStructClass()
        {
            _sintSchet = "88888";
            _kosgu = "888";
            for (int i = 0, j = 4; j < dbFieldNumber.N; i++, j++)
            {
                _x[i] = 0;
            }
        }

        public bool IsThis(string[] ss)
        {
            return (_sintSchet == ss[2]) && (_kosgu == ss[3]);
        }

        public void Update(string[] ss)
        {
            for (int i = 0, j = 4; j < dbFieldNumber.N; i++, j++)
            {
                try
                {
                    if ((ss[j] != null) && (ss[j].Trim().Length != 0))
                    {
                        _x[i] += Convert.ToDouble(ss[j].Replace(',', '.'), provider);
                    }
                }
                catch (Exception e)
                {
                    ErrorInfoMsg("Попытка конвертации в число: " + e.Message + ", параметр [" + ss[j] + "]");
                    Environment.Exit(0);
                }

            }
        }

        public string Output()
        {
            string sss = "";
            bool ok = false;
            for (int i = 0, j = 4, k = 2; j < dbFieldNumber.N; i++, j++, k++)
            {
                if (_x[i] != 0)
                {
                    sss += (" _x" + k.ToString() + "=\"" + _x[i].ToString("F2") + "\"");
                    ok = true;
                }

            }
            if (ok)
            {
                return (indent + "<Data СинтСчёт = \"" + _sintSchet + "\"  КОСГУ = \"" + _kosgu + "\"" + sss + ">\n");
            }
            return null;
        }
    }

    private class DataListClass : List<DataStructClass>
    {
        private DataStructClass sumData = new();

        public string SumDataOutput()
        {
            return sumData.Output();
        }

        public void AddData(string[] prm)
        {
            sumData.Update(prm);

            foreach (DataStructClass item in this)
            {
                if (item.IsThis(prm))
                {

                    item.Update(prm);
                    return;
                }
            }
            Add(new DataStructClass(prm));
        }
    }

    private static void ErrorInfoMsg(string message)
    {
        MessageBox.Show(message, MainWindow.MAINCAPTION, MessageBoxButton.OK, MessageBoxImage.Hand);
    }

    public static int Run(ObservableCollection<ShowList> prmshowList)
    {
        // Сначала спросим, правда ли пользователь хочет выгрузить данные?
        // Или случайно нажал не ту кнопку...
        SaveFileDialog saveFileDialog = new();

        saveFileDialog.Filter = "Файлы XML (*.xml)|*.xml|All files (*.*)|*.*";
        saveFileDialog.FilterIndex = 1;
        saveFileDialog.RestoreDirectory = true;

        if (saveFileDialog.ShowDialog() == false)
            return 0;


        // Теперь - подсчёт.
        provider = new NumberFormatInfo() { NumberDecimalSeparator = ".", NumberGroupSeparator = "" };

        DataListClass buffer = new DataListClass();

        foreach (ShowList show in prmshowList)
        {
            buffer.AddData(show.ListX);
        }


        // Теперь - отчёт.
        string fileName = saveFileDialog.FileName;


        Encoding cp1251;

        Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

        try
        {
            cp1251 = Encoding.GetEncoding("windows-1251");
        }
        catch
        {
            ErrorInfoMsg("Невозможно загрузить кодировку windows-1251, будет использована кодировка по умолчанию.");
            cp1251 = Encoding.Default;
        }

        int linecount = 0;

        try
        {
            using (StreamWriter sw = new StreamWriter(fileName, false, cp1251))
            {
                sw.Write(header);


                foreach (DataStructClass item in buffer)
                {
                    string s = item.Output();
                    if (s != null)
                    {
                        sw.Write(s);
                        linecount++;
                    }
                }
                if (linecount > 0)
                {
                    sw.Write(buffer.SumDataOutput());
                }
                sw.Write(footer);
            }
        }
        catch (IOException e)
        {
            ErrorInfoMsg("Ошибка чтения файла: " + e.Message);
            return -1;
        }
        return linecount;
    }
}
*/


//
//  *** Выгрузка в Эксель с помощью OpenXML - оставлено для справки, на тот случай, если понадобится вспомнить что-то
//

/*  
    public class SaveToExcel
    {
        public static int Run(MainWindow main, ObservableCollection<ShowList> prmshowList)
        {
            // Сначала проверим, существует ли шаблон
            string templateName = "template.xlsx";
            string templateFullPath = MainWindow.curDir + "\\" + templateName;

            if (!File.Exists(templateFullPath))
            {
                ErrorInfoMsg("Отсутствует файл шаблона с именем " + templateFullPath + ", формирование документа прекращено.");
                return -1;
            }

            // Спросим, правда ли пользователь хочет выгрузить данные?
            // Или случайно нажал не ту кнопку...
            SaveFileDialog saveFileDialog = new SaveFileDialog();

            saveFileDialog.Filter = "Файлы XLSX (*.xlsx)|*.xlsx|All files (*.*)|*.*";
            saveFileDialog.FilterIndex = 1;
            saveFileDialog.RestoreDirectory = true;

            if (saveFileDialog.ShowDialog() == false)
                return 0;

            string targetFileFullPath = saveFileDialog.FileName;
            try
            {
                File.Copy(templateFullPath, targetFileFullPath, true);
            }
            catch (Exception e)
            {
                ErrorInfoMsg("Ошибка создания файла: " + e.Message);
                return -1;
            }


            // И вперёд.

            NumberFormatInfo provider = new NumberFormatInfo() { NumberDecimalSeparator = ".", NumberGroupSeparator = "" };

            double[] summary = new double[dbFieldNumber.VN];

            string emptyCellMark = "--";
            //string emptyCellMark = "-"; - однократное тире портит документ

            uint counter = 0;

            using (SpreadsheetDocument spreadsheetDocument = SpreadsheetDocument.Open(targetFileFullPath, true))
            {
                WorkbookPart workbookPart = spreadsheetDocument.WorkbookPart;
                WorksheetPart worksheetPart = workbookPart.WorksheetParts.First();
                //WorksheetPart worksheetPart = GetWorksheetPartByName(spreadSheet, "Бюджет");

                if (worksheetPart != null)
                {
                    Row row;
                    Cell cell;
                    
                    try
                    {
                        string[] buf; // /// = new string[dbFieldNumber.N];
                        uint rowIndex = 6;

                        foreach (ShowList show in prmshowList)
                        {
                            buf = show.ListX;

                            row = MyGetRow(worksheetPart, rowIndex);

                            cell = MyNewCell(worksheetPart, row, "A" + rowIndex);
                            cell.DataType = new EnumValue<CellValues>(CellValues.SharedString);
                            cell.CellValue = new CellValue(buf[0] + " " + buf[1] + " " + buf[2] + " " + buf[3]);


                            for (int i = 0, j = 4; j < dbFieldNumber.N; i++, j++)
                            {
                                double dd = Convert.ToDouble(buf[j].Replace(',', '.'), provider);
                                                                
                                cell = MyNewCell(worksheetPart, row, abcFunc(i) + rowIndex);

                                if (dd != 0)
                                {
                                    cell.DataType = new EnumValue<CellValues>(CellValues.Number);
                                    cell.CellValue = new CellValue(buf[j]);
                                    summary[i] += dd;
                                }
                                else
                                {
                                    cell.DataType = new EnumValue<CellValues>(CellValues.SharedString);
                                    cell.CellValue = new CellValue(emptyCellMark);
                                }
                            }

                            rowIndex++;

                            //
                            // Сообщение о прогрессе - но оно будет работать только в отдельной нити - и то если переделать её
                            // ***   main.SetInfo("Выгрузка в файл Excel: создано строк " + (++counter).ToString());
                            //
                        }

                        // Пишем итоги
                        row = MyGetRow(worksheetPart, rowIndex);
                        cell = MyNewCell(worksheetPart, row, "A" + rowIndex);
                        cell.DataType = new EnumValue<CellValues>(CellValues.SharedString);
                        cell.CellValue = new CellValue("Всего задолженности:");

                        for (int i = 0; i < dbFieldNumber.VN; i++)
                        {
                            cell = MyNewCell(worksheetPart, row, abcFunc(i) + rowIndex);
                            if (summary[i] != 0)
                            {
                                cell.DataType = new EnumValue<CellValues>(CellValues.Number);
                                cell.CellValue = new CellValue(summary[i]);
                            }
                            else
                            {
                                cell.DataType = new EnumValue<CellValues>(CellValues.SharedString);
                                cell.CellValue = new CellValue(emptyCellMark);
                            }
                        }

                    }
                    catch (Exception e)
                    {
                        ErrorInfoMsg("Формирование документа прервано из за ошибки: " + e.Message);

                        worksheetPart.Worksheet.Save();
                        workbookPart.Workbook.Save();
                        spreadsheetDocument.Save();

                        return -1;
                    }

                }
                else
                {
                    ErrorInfoMsg("Не могу получить указатель на лист документа (возможно, был повреждён файл шаблона). Формирование документа отменяется.");
                    return -1;
                }

                // По идее, это должно делаться в finally... ну, да ладно.
                worksheetPart.Worksheet.Save();
                workbookPart.Workbook.Save();
                spreadsheetDocument.Save();
                return ((int)counter + 1);
            }

            // Получить номер столбца по индексу заносимого числового значения.
            // Делаем вычислением, вместо того, чтобы заводить массив вроде этого
            //            string[] abc = new string[] { "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N" };
            // Это в таком виде работает только для однобуквенных имён - но нам достаточно этого
            static string abcFunc(int n)
            {
                string s = "B";
                if (n == 0)
                    return s;
                return string.Format("{0}", (char)(((uint)s[0]) + n));
            }

            static void ErrorInfoMsg(string message)
            {
                MessageBox.Show(message, MainWindow.MAINCAPTION, MessageBoxButton.OK, MessageBoxImage.Hand);
            }


            // Мой (препарированный) вариант получения строки

            static Row MyGetRow(WorksheetPart worksheetPart, uint rowIndex)
            {
                SheetData sheetData = worksheetPart.Worksheet.GetFirstChild<SheetData>();
                Row row;

                // Если в шаблоне уже есть строка с таким номером, берём её, но чистим.
                if (sheetData.Elements<Row>().Where(r => r.RowIndex == rowIndex).Any())
                {
                    row = sheetData.Elements<Row>().Where(r => r.RowIndex == rowIndex).First();                    
                }
                // ...иначе делаем новенькую.
                else
                {
                    row = new Row() { RowIndex = rowIndex };
                    sheetData.Append(row);
                }
                worksheetPart.Worksheet.Save();
                return row;
            }

            // Создание новой ячейки
            // Параметр string cellReference = columnName + rowIndex; - передаём 
            static Cell MyNewCell(WorksheetPart worksheetPart, Row row, string cellReference)
            {
                // Если есть уже такая ячейка, следует возвратить её.                
                if (row.Elements<Cell>().Any(c => c.CellReference.Value == cellReference))
                {
                    return row.Elements<Cell>().Where(c => c.CellReference.Value == cellReference).First();
                }
                
                // Делаем новую ячейку
                Cell newCell = new()
                {
                    CellReference = cellReference
                };
                
                Cell refCell = null;
                foreach (Cell cell in row.Elements<Cell>())
                {
                    if (string.Compare(cell.CellReference.Value, cellReference, true) > 0)
                    {
                        refCell = cell;
                        break;
                    }
                }

                row.InsertBefore(newCell, refCell);
                //  row.InsertAfter(newCell, row.Last()); - если бы мы были уверены, что других нет...

                worksheetPart.Worksheet.Save();
                return newCell;
            }

        }
    }

*/
