﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static OBTtest_MS.DataList;

namespace OBTtest_MS
{
    // ***
    // Логика взаимодействия для EditWindow.xaml
    // ***


    public partial class EditWindow : Window
    {
        // Промежуточный буфер данных
        private string[] recData;

        // Конструктор для новой записи
        public EditWindow()
        {
            InitializeComponent();

            // Если поля формы неявно инициализируются, то можно просто объявить промежуточный буфер...
            //recData = new string[dbFieldNumber.N];

            // ... однако лучше, когда всё явственно видно - на случай, если понадобятся правки
            recData = new string[]{"00000000000000000","0","00000","000",
                "0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00"};
            ToWindow();
        }

        // Конструктор для редактирования/копирования
        // (Копирование происходит редактированием кода - чтобы не делать отдельной кнопки "Копировать" на Главнои форме)
        public EditWindow(string[] prm)
        {
            InitializeComponent();
            recData = prm;
            ToWindow();
        }

        // Занести данные в поля формы
        private void ToWindow()
        {
            X1AValue.Text = recData[0];
            X1BValue.Text = recData[1];
            X1VValue.Text = recData[2];
            X1GValue.Text = recData[3];
            X2Value.Text = recData[4];
            X3Value.Text = recData[5];
            X4Value.Text = recData[6];
            X5Value.Text = recData[7];
            X6Value.Text = recData[8];
            X7Value.Text = recData[9];
            X8Value.Text = recData[10];
            X9Value.Text = recData[11];
            X10Value.Text = recData[12];
            X11Value.Text = recData[13];
            X12Value.Text = recData[14];
            X13Value.Text = recData[15];
            X14Value.Text = recData[16];
        }

        // Взять данные из полей формы
        private string[] FromWindow()
        {
            return new string[] {X1AValue.Text, X1BValue.Text, X1VValue.Text, X1GValue.Text,
                X2Value.Text.Replace(',', '.'), X3Value.Text.Replace(',', '.'), X4Value.Text.Replace(',', '.'),
                X5Value.Text.Replace(',', '.'), X6Value.Text.Replace(',', '.'), X7Value.Text.Replace(',', '.'),
                X8Value.Text.Replace(',', '.'), X9Value.Text.Replace(',', '.'), X10Value.Text.Replace(',', '.'),
                X11Value.Text.Replace(',', '.'), X12Value.Text.Replace(',', '.'), X13Value.Text.Replace(',', '.'),
                X14Value.Text.Replace(',', '.')};
        }

        // Возврат без обновления данных
        private void CancelBtn_Click(object sender, RoutedEventArgs e)
        {
            
            MainWindow main = this.Owner as MainWindow;
            Close();
            main.mWindowMode.FromChild();
        }

        // Изменить или добавить строку в БД и перечитать все данные из БД
        private void AcceptBtn_Click(object sender, RoutedEventArgs e)
        {

            MainWindow main = this.Owner as MainWindow;

            // Для простоты дела работаем с данными через процедуры Главного Окна
            main.UpdateRecordInDB(FromWindow());
            main.ReReadAll();

            Close();
            main.mWindowMode.FromChild();
        }
    }
}
